//RONIT SAINI
//210905322
//4AUG 2023
//LAB 1 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <fcntl.h>


int main() {
    int len, result, sockfd, n = 1, i;
    struct sockaddr_in address;
    char ch[256], buf[256];
    // Create a socket for the client
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    // Name the socket as agreed with the server
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = inet_addr("172.16.58.110");
    address.sin_port = htons(10200);
    len = sizeof(address);
    // Connect your socket to the server’s socket
    result = connect(sockfd, (struct sockaddr *)&address, len);
    if (result == -1) {
        perror("\nCLIENT ERROR");
        exit(1);
    }
    // You can now read and write via sockfd (Logic for problem mentioned here)
    printf("Enter anything: ");
    gets(ch);
    ch[strlen(ch)] = '\0';

    for(i = 0; i < strlen(ch); i++) 
            ch[i] = ch[i] + 4;

    write(sockfd, ch, strlen(ch));
    printf("Message back from the server: ");
    while (n) {
        n = read(sockfd, buf, sizeof(buf));
        puts(buf);
    }
}
